# Clear the cache
Rails.cache.write("portus-checks", nil)
