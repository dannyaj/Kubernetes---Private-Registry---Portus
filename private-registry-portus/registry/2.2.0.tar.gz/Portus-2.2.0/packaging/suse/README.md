In order to create a SUSE RPM, run

./make_spec.rb

and then use this in the open suse build service to build a package
