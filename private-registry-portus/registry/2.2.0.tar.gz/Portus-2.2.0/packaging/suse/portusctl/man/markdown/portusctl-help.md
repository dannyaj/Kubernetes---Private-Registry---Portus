PORTUSCTL 1 "portusctl User manuals" "SUSE LLC." "AUGUST 2016"
==============================================================

# NAME
portusctl help \- Show a help message for the given command

# SYNOPSIS

**portusctl help** \<command\>

# DESCRIPTION
The **help** command shows a help message for the given command.

# HISTORY
August 2016, created by Miquel Sabaté Solà <msabate@suse.com>
