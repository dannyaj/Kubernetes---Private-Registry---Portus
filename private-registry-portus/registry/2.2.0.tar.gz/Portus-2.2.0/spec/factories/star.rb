FactoryGirl.define do
  factory :star do
    repository
    user
  end
end
