class NamespaceSerializer < ActiveModel::Serializer
  attributes :id, :name
end
