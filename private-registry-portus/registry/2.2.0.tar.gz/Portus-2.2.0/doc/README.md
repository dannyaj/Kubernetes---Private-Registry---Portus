# Documentation

This directory is no longer used for storing files regarding the documentation
of Portus. Instead, you have two options:

1. The [wiki](https://github.com/SUSE/Portus/wiki): it contains all the
   documentation regarding the development of Portus.
2. Our [official site](http://port.us.org/): it contains all the user
   documentation, the list of features, etc.
